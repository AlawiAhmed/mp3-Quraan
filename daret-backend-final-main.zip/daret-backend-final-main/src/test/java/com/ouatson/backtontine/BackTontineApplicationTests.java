package com.ouatson.backtontine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackTontineApplicationTests {

    @Test
    void contextLoads() {
    }

}
