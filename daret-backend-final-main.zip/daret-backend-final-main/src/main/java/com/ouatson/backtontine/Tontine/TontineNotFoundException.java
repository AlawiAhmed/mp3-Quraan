package com.ouatson.backtontine.Tontine;

public class TontineNotFoundException extends RuntimeException {
    public TontineNotFoundException(String message) {
        super(message);
    }
}
