package com.ouatson.backtontine.Security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AndRequestMatcher;

public class SecurityConfig {
    @Autowired
    private final UserDetailsService userDetailsService;

    public SecurityConfig(UserDetailsService userDetailsService) {
        this.userDetailsService = userDetailsService;
    }

    @Autowired
    private BCryptPasswordEncoder encoder;

    @Bean
    protected SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity)throws Exception{
        return httpSecurity.csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth.anyRequest().permitAll())
                .build();
 /*       httpSecurity.authorizeRequests()
                .antMatchers("/enregistrer" "/confirm-reset").permitAll()
                .antMatchers("/connexion").authenticated()
                .antMatchers("/mestontines/**", "/userI/**", "/userE/**").authenticated()
              //  .requestMatchers("/admin").hasAuthority("ADMIN")
                .anyRequest().authenticated()

                .and()
                .formLogin().permitAll() // Enable form-based login for permitted URLs
                .defaultSuccessUrl("/connexion",true)

                .and()
//                .logout()
//                .logoutRequestMatcher(new AndRequestMatcher("/")).permitAll() // Logout URL accessible to all

//                .and()
//                .exceptionHandling()
//                .accessDeniedPage("/exception");

                .authenticationProvider(authenticationProvider());
        return httpSecurity.build();*/
    }

    @Bean
    public AuthenticationProvider authenticationProvider(){
        DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
        daoAuthenticationProvider.setUserDetailsService(userDetailsService);
        daoAuthenticationProvider.setPasswordEncoder(encoder);
        return daoAuthenticationProvider;
    }
}
